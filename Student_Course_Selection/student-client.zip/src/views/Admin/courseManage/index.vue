<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "index.vue",
}
</script>

<style scoped>

</style>