<template>
  <div>
    <el-container>
      <el-main>
      管理员！欢迎！
      </el-main>

    </el-container>
    <img src="https://techla-img.oss-cn-hangzhou.aliyuncs.com/CODE/WEB/DSC06465.jpg" width=100% height=800px>
  </div>
</template>

<script>
import Logout from "@/components/logout";
export default {
  name: "home",
  components: {Logout},
}
</script>

<style scoped>

</style>
